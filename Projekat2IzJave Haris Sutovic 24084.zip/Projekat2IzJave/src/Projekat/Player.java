package Projekat;

public class Player extends GameObject {
	
	private String name;
	private int health;
	
	public Player(int x, int y, int width, int height, String name, int health) {
		super(x, y, width, height);
		setName(name);
        setHealth(health);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		name = name.trim();
		
		String[] rijeci = name.split(" ");
		String novoIme = "";
		
		for (int i = 0; i < rijeci.length; i++) {
			if (!rijeci[i].equals("")) {
				if (!novoIme.equals("")) {
					novoIme += " ";
				}
				
			novoIme += rijeci[i].substring(0, 1).toUpperCase() + rijeci[i].substring(1).toLowerCase();	
			}
		}
		
		if (novoIme.equals("")) {
			this.name = "Player";
		} else {
			this.name = novoIme;
		}
		
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if (health < 0) {
			this.health = 0;
		} else if (health > 100) {
			this.health = 100;
		} else {
			this.health = health;
		}
	}
	
	@Override
	public String toString() {
		return "Player[" + name + "] " + super.toString() + " HP=" + health;
	}
	
	
	
	

}
