package Projekat;

import java.util.ArrayList;

public class Game {
	
	private Player igrac;
	private ArrayList<Enemy> neprijatelji;
	private ArrayList<String> dnevnik;
	
	public Game(Player igrac) {
		this.igrac = igrac;
		neprijatelji = new ArrayList<Enemy>();
		dnevnik = new ArrayList<String>();
	}
	
	public Player getPlayer() {
		return igrac;
	}
	
	public void addEnemy(Enemy neprijatelj) {
		neprijatelji.add(neprijatelj);
		dnevnik.add("Dodat neprijatelj: " + neprijatelj.getType());
		
	}
	
	public boolean checkCollision(Player igrac, Enemy neprijatelj) {
		return igrac.provjeriSudar(neprijatelj);
	}
	
	public void decreaseHealth(Player igrac, Enemy neprijatelj) {
		int staroZdravlje = igrac.getHealth();
		int novoZdravlje = staroZdravlje - neprijatelj.getDamage();
		
		if (novoZdravlje < 0) {
			novoZdravlje = 0;
		}
		
		igrac.setHealth(novoZdravlje);
		
		dnevnik.add("UDARAC: " + neprijatelj.getType() + " -> " + igrac.getName() + " HP " + staroZdravlje + " -> " + novoZdravlje);
	}
	
	public ArrayList<Enemy> findByType(String trazeniTip) {
		ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
		
		for (int i = 0; i < neprijatelji.size(); i++) {
			Enemy neprijatelj = neprijatelji.get(i);
			
			if (neprijatelj.containsType(trazeniTip)) {
				rezultat.add(neprijatelj);
			}
		}
		return rezultat;
		
	}
	
	public void resolveCollisions() {
		for (int i = 0; i < neprijatelji.size(); i++) {
			Enemy neprijatelj = neprijatelji.get(i);
			
			if (checkCollision(igrac, neprijatelj)) {
				decreaseHealth(igrac, neprijatelj);
			}
			
		}
	}
	
	public void dodajNeprijateljaIzStringa(String zapis) {
		String[] djelovi = zapis.split(";");
		String[] podaci = djelovi[0].split(":");
		String[] pozicija = podaci[1].split(",");
		String[] dimenzije = podaci[2].split("x");
		
		String type = podaci[0];
		
		 int x = Integer.parseInt(pozicija[0]);
		    int y = Integer.parseInt(pozicija[1]);
		    int width = Integer.parseInt(dimenzije[0]);
		    int height = Integer.parseInt(dimenzije[1]);
		    int damage = Integer.parseInt(djelovi[2]);
		   
		    Enemy neprijatelj;
		    
		    if (djelovi.length > 3 && djelovi[3].trim().equalsIgnoreCase("boss")) {
		        neprijatelj = new BossEnemy(x, y, width, height,type, damage, 120);
		    } else {
		        neprijatelj = new MeleeEnemy(x, y, width, height, type, damage, 60);
		    }

		    addEnemy(neprijatelj);
		}
		    
	public void ispisiNeprijatelje() {
	    for (int i = 0; i < neprijatelji.size(); i++) {
	        System.out.println(neprijatelji.get(i));
	    }
	}

	public void ispisiDnevnik() {
	    for (int i = 0; i < dnevnik.size(); i++) {
	        System.out.println(dnevnik.get(i));
	    }
	}
	
	public static void main(String[] args) {
	    Player igrac = new Player(10, 5, 32, 32,"Haris Sutovic", 85);

	    Game igra = new Game(igrac);

	    Enemy neprijatelj1 =
	            new MeleeEnemy(12, 5, 16, 16, "Goblin", 20, 60);

	    igra.addEnemy(neprijatelj1);

	    igra.dodajNeprijateljaIzStringa("Goblin King:12,5;32x32;25;boss");

	    System.out.println("Igrac prije sudara:");
	    System.out.println(igra.getPlayer());

	    System.out.println("\nSvi neprijatelji:");
	    igra.ispisiNeprijatelje();

	    System.out.println("\nNeprijatelji koji sadrze gob:");
	    ArrayList<Enemy> rezultat = igra.findByType("gob");

	    for (int i = 0; i < rezultat.size(); i++) {
	        System.out.println(rezultat.get(i));
	    }

	    System.out.println("\nObrada sudara:");
	    igra.resolveCollisions();

	    System.out.println("\nIgrac poslije sudara:");
	    System.out.println(igra.getPlayer());

	    System.out.println("\nKompletan dnevnik dogadjaja:");
	    igra.ispisiDnevnik();
	}
}
