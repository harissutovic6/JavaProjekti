package Projekat;

public class GameObject {
	
	private int x;
	private int y;
	private int width;
	private int height;
	
	public GameObject(int x, int y, int width, int height) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
	
	
	public boolean provjeriSudar(GameObject drugiObjekat) {
		return x < drugiObjekat.x + drugiObjekat.width && x + width > drugiObjekat.x && y < drugiObjekat.y + drugiObjekat.height && y + height > drugiObjekat.y;
	}
	
	@Override
	public String toString() {
		return "@ (" + x + "," + y + ") " + width + "x" + height;
	}
	
	

}
