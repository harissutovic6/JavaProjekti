package Projekat;

public class MeleeEnemy extends Enemy {

	public MeleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
	}
	
	

}
