package Projekat;

public class BossEnemy extends Enemy {

	public BossEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
	}
	
	@Override
	public int getDamage() {
		return super.getDamage() * 2;
	}

	@Override
	public String toString() {
        return "BossEnemy[" + getType() + "] "
                + super.toString().substring(
                        super.toString().indexOf("@"))
                .replace(" DMG=" + super.getDamage(),
                        " DMG=" + super.getDamage() + "x2");
    }
}
