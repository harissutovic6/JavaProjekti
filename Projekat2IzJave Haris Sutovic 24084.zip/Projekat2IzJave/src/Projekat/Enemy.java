package Projekat;

public class Enemy extends GameObject {
	
	private String type;
	private int damage;
	private int health;
	
	public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height);
		setType(type);
		setDamage(damage);
		setHealth(health);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if (type == null || type.trim().equals("")) {
			this.type = "Enemy";
		} else {
			this.type = type.trim();
		}
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		 if (damage < 0) {
	            this.damage = 0;
	        } else if (damage > 100) {
	            this.damage = 100;
	        } else {
	            this.damage = damage;
	            
	        }	 
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		if (health < 0) {
            this.health = 0;
        } else {
            this.health = health;
        }
	}
	
	public boolean containsType(String trazeniTip) {
		if (trazeniTip == null) {
			return false;
		}
		
		return type.toLowerCase().contains(trazeniTip.trim().toLowerCase());
	}
	
	@Override
	public String toString() {
        return "Enemy[" + type + "] " + super.toString() + " DMG=" + getDamage() + " HP=" + health;
	
	
	
	}
}
